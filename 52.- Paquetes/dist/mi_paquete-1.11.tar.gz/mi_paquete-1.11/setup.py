# setup.py
from setuptools import setup

setup(
    name='mi_paquete',
    version='1.11',
    packages=['Empaquetado'],
    install_requires=[],
    author='josemanuel.adasme',
    author_email='jmadasme@gmail.com'
)